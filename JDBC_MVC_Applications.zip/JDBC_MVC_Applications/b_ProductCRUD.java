
import java.sql.*;
import java.util.Scanner;

public class b_ProductCRUD {
    static final String DB_URL = "jdbc:mysql://localhost:3306/your_database";
    static final String USER = "your_user";
    static final String PASS = "your_password";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Scanner scanner = new Scanner(System.in)) {

            conn.setAutoCommit(false);
            boolean exit = false;

            while (!exit) {
                System.out.println("\n1. Add Product\n2. View Products\n3. Update Product\n4. Delete Product\n5. Exit");
                System.out.print("Choose option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1 -> addProduct(conn, scanner);
                    case 2 -> viewProducts(conn);
                    case 3 -> updateProduct(conn, scanner);
                    case 4 -> deleteProduct(conn, scanner);
                    case 5 -> exit = true;
                    default -> System.out.println("Invalid choice!");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void addProduct(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter ID, Name, Price, Quantity: ");
        int id = scanner.nextInt();
        String name = scanner.next();
        double price = scanner.nextDouble();
        int qty = scanner.nextInt();

        try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO Product VALUES (?, ?, ?, ?)")) {
            stmt.setInt(1, id);
            stmt.setString(2, name);
            stmt.setDouble(3, price);
            stmt.setInt(4, qty);
            stmt.executeUpdate();
            conn.commit();
            System.out.println("Product added.");
        } catch (SQLException e) {
            conn.rollback();
            System.out.println("Failed to add product.");
        }
    }

    static void viewProducts(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Product")) {

            while (rs.next()) {
                System.out.println(rs.getInt("ProductID") + " " +
                                   rs.getString("ProductName") + " " +
                                   rs.getDouble("Price") + " " +
                                   rs.getInt("Quantity"));
            }
        }
    }

    static void updateProduct(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter ProductID to update and new Quantity: ");
        int id = scanner.nextInt();
        int qty = scanner.nextInt();

        try (PreparedStatement stmt = conn.prepareStatement("UPDATE Product SET Quantity = ? WHERE ProductID = ?")) {
            stmt.setInt(1, qty);
            stmt.setInt(2, id);
            int rows = stmt.executeUpdate();
            conn.commit();
            System.out.println(rows > 0 ? "Updated successfully." : "Product not found.");
        } catch (SQLException e) {
            conn.rollback();
        }
    }

    static void deleteProduct(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter ProductID to delete: ");
        int id = scanner.nextInt();

        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM Product WHERE ProductID = ?")) {
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            conn.commit();
            System.out.println(rows > 0 ? "Deleted successfully." : "Product not found.");
        } catch (SQLException e) {
            conn.rollback();
        }
    }
}
