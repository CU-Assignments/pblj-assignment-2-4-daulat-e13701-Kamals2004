
package view;

import controller.StudentController;
import model.Student;
import java.sql.*;
import java.util.*;

public class StudentApp {
    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "user", "pass");
             Scanner sc = new Scanner(System.in)) {

            StudentController controller = new StudentController(conn);
            boolean exit = false;

            while (!exit) {
                System.out.println("\n1. Add Student\n2. View Students\n3. Exit");
                switch (sc.nextInt()) {
                    case 1 -> {
                        Student s = new Student();
                        System.out.print("ID Name Dept Marks: ");
                        s.setStudentID(sc.nextInt());
                        s.setName(sc.next());
                        s.setDepartment(sc.next());
                        s.setMarks(sc.nextDouble());
                        controller.addStudent(s);
                    }
                    case 2 -> {
                        List<Student> students = controller.getAllStudents();
                        students.forEach(std -> System.out.println(std.getStudentID() + " " + std.getName() + " " + std.getDepartment() + " " + std.getMarks()));
                    }
                    case 3 -> exit = true;
                    default -> System.out.println("Invalid option.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
