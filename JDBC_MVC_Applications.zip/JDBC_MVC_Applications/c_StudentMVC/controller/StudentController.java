
package controller;

import model.Student;
import java.sql.*;
import java.util.*;

public class StudentController {
    private final Connection conn;

    public StudentController(Connection conn) {
        this.conn = conn;
    }

    public void addStudent(Student s) throws SQLException {
        String sql = "INSERT INTO Student VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, s.getStudentID());
            stmt.setString(2, s.getName());
            stmt.setString(3, s.getDepartment());
            stmt.setDouble(4, s.getMarks());
            stmt.executeUpdate();
        }
    }

    public List<Student> getAllStudents() throws SQLException {
        List<Student> list = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Student")) {

            while (rs.next()) {
                Student s = new Student();
                s.setStudentID(rs.getInt("StudentID"));
                s.setName(rs.getString("Name"));
                s.setDepartment(rs.getString("Department"));
                s.setMarks(rs.getDouble("Marks"));
                list.add(s);
            }
        }
        return list;
    }
}
